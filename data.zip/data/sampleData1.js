export const sampleData = [
    { id: 1, name: "Shrihari", email: "shri@gmail.com" },
    { id: 2, name: "Shrinu", email: "shrinu@gmail.com" },
    { id: 3, name: "Jyothi", email: "jyothi@gmail.com" }
  ];