// /pages/index.js
import React, { useState } from "react";
import ButtonComponent from "../components/ButtonComponent";
import FormComponent from "../components/FormComponent";
import GridComponent from "../components/GridComponent";
import { Container, Typography } from "@mui/material";
import { sampleData } from "../data/sampleData1";

function Home() {
  const [users, setUsers] = useState(sampleData);

  // Function to add a new user
  const addUser = (user) => {
    setUsers([...users, { id: users.length + 1, ...user }]);
  };

  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        Welcome to Next.js with MUI
      </Typography>
      <ButtonComponent text="Click Me" onClick={() => alert("Button Clicked!")} />
      <FormComponent onAdd={addUser} />
      <GridComponent data={users} />
    </Container>
  );
}

export default Home;
