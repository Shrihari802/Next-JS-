// /components/FormComponent.js
import React, { useState } from "react";
import { TextField, Button } from "@mui/material";

const FormComponent = ({ onAdd }) => {
  const [input, setInput] = useState({ name: "", email: "" });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (input.name && input.email) {
      onAdd(input); // Call parent function to update the list
      setInput({ name: "", email: "" }); // Reset form
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <TextField
        label="Name"
        variant="outlined"
        fullWidth
        value={input.name}
        onChange={(e) => setInput({ ...input, name: e.target.value })}
        margin="normal"
      />
      <TextField
        label="Email"
        variant="outlined"
        fullWidth
        value={input.email}
        onChange={(e) => setInput({ ...input, email: e.target.value })}
        margin="normal"
      />
      <Button type="submit" variant="contained" color="primary">
        Add User
      </Button>
    </form>
  );
};

export default FormComponent;
